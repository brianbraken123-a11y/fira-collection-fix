# Fira Collection

Katalog affiliate ringan berbasis React dan Vite. Produk langsung tampil di halaman; katalog tetap kosong sampai data produk asli ditambahkan. Tidak ada login atau backend.

## Menjalankan lokal

```bash
npm install
npm run dev
```

Buka URL lokal yang ditampilkan Vite. Untuk menghasilkan versi produksi, jalankan `npm run build`; pratinjau hasilnya dengan `npm run preview`.

## Mengisi katalog

Edit `src/data/products.js`. Ganti entri contoh dengan data produk asli:

```js
{
  id: 'id-produk-unik',
  name: 'Nama produk',
  image: 'https://domain-anda.com/foto-produk.webp',
  affiliateUrl: 'https://tautan-affiliate-asli',
  description: 'Informasi singkat produk.',
  active: true,
}
```

Pakai URL HTTPS asli untuk foto dan tautan affiliate. Parameter tracking dipertahankan apa adanya. Pastikan `id` unik. Hanya produk berstatus aktif dengan nama, URL gambar HTTPS, dan URL affiliate HTTPS yang valid akan ditampilkan. Bila gambar gagal dimuat, kartu menampilkan fallback. Gambar menggunakan `object-fit: contain` agar produk tidak terpotong.

Data contoh saat ini dinonaktifkan dan tidak memuat tautan atau foto yang seolah-olah asli. Ganti nama, deskripsi, gambar, dan tautan affiliate dengan data produk sebenarnya sebelum mengaktifkan produk.

## Deploy ke Vercel

Impor repository GitHub di Vercel dan gunakan pengaturan berikut (preset Vite):

- Framework preset: **Vite**
- Build command: `npm run build`
- Output directory: `dist`
- Install command: `npm install`

Tidak ada environment variable yang diperlukan. Jangan memasukkan kredensial atau token ke file frontend. Deployment belum dilakukan.
