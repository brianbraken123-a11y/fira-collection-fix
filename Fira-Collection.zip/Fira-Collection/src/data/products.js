// Ganti placeholder di bawah dengan produk asli sebelum mengaktifkan katalog.
// Produk baru akan tampil hanya jika active=true dan image serta affiliateUrl valid.
export const products = [
  {
    id: 'contoh-produk-1',
    name: 'Contoh nama produk',
    image: '', // Isi URL HTTPS foto produk asli.
    affiliateUrl: '', // Isi URL HTTPS affiliate asli tanpa mengubah tracking.
    description: 'Contoh deskripsi singkat produk.',
    active: false,
  },
]

export const activeProducts = products.filter((product) => {
  if (!product.active || !product.name?.trim() || !product.image || !product.affiliateUrl) return false

  try {
    return new URL(product.image).protocol === 'https:' && new URL(product.affiliateUrl).protocol === 'https:'
  } catch {
    return false
  }
})
