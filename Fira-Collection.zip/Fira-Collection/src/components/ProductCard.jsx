import { useState } from 'react'

export default function ProductCard({ product }) {
  const [imageFailed, setImageFailed] = useState(false)

  return (
    <article className="product-card">
      <a
        className="product-link"
        href={product.affiliateUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label={`Lihat ${product.name}`}
      >
        <div className="product-image-wrap">
          {imageFailed ? (
            <div className="image-fallback" role="img" aria-label="Foto produk tidak tersedia">Foto tidak tersedia</div>
          ) : (
            <img
              className="product-image"
              src={product.image}
              alt={product.name}
              loading="lazy"
              onError={() => setImageFailed(true)}
            />
          )}
        </div>
        <div className="product-copy">
          <h2>{product.name}</h2>
          {product.description && <p>{product.description}</p>}
          <span className="product-cta">Lihat produk <span aria-hidden="true">↗</span></span>
        </div>
      </a>
    </article>
  )
}
