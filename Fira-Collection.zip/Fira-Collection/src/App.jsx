import ProductCard from './components/ProductCard.jsx'
import { activeProducts } from './data/products.js'

function Sparkle() {
  return <span className="sparkle" aria-hidden="true">✳</span>
}

export default function App() {
  return (
    <main className="page-shell">
      <header className="site-header">
        <a className="wordmark" href="#top" aria-label="Fira Collection, beranda">fira<span>.</span></a>
        <span className="header-note"><Sparkle /> curated with love</span>
      </header>

      <section className="intro" id="top" aria-labelledby="page-title">
        <p className="eyebrow">THE LITTLE THINGS, PICKED FOR YOU</p>
        <h1 id="page-title">Pilihan <span>favorit</span>,<br className="mobile-break" /> satu tempat.</h1>
        <p className="intro-copy">Temukan koleksi pilihan dari Fira, dikurasi dengan sepenuh hati.</p>
      </section>

      <section className="catalog" aria-labelledby="catalog-title">
        <div className="section-heading">
          <h2 id="catalog-title">Koleksi pilihan</h2>
          <span className="item-count">{String(activeProducts.length).padStart(2, '0')} ITEMS</span>
        </div>
        {activeProducts.length > 0 ? (
          <div className="product-grid">
            {activeProducts.map((product) => <ProductCard key={product.id} product={product} />)}
          </div>
        ) : (
          <div className="empty-state">
            <div className="empty-icon"><Sparkle /></div>
            <h3>Koleksi sedang disiapkan</h3>
            <p>Pilihan spesial Fira akan segera hadir di sini. Mampir lagi, ya!</p>
          </div>
        )}
      </section>

      <footer className="site-footer">
        <a className="footer-mark" href="#top">fira<span>.</span></a>
        <span>Made with care <span className="heart">♥</span></span>
      </footer>
    </main>
  )
}
